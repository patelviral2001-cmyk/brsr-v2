# Secrets Manager bootstrapping. We pre-create the secret containers; the
# initial values are written by ./infra/scripts/generate-secrets.sh or by an
# operator. Rotation Lambdas wire later.

variable "name"        { type = string }
variable "environment" { type = string }
variable "kms_key_arn" { type = string }
variable "tags"        { type = map(string), default = {} }

resource "random_password" "db_master" {
  length      = 40
  special     = true
  override_special = "!#%&*+-=?^_~"
}

resource "random_password" "redis_auth" {
  length  = 64
  special = false
}

resource "aws_secretsmanager_secret" "db_master" {
  name                    = "${var.name}/db/master"
  kms_key_id              = var.kms_key_arn
  recovery_window_in_days = 7
  tags                    = var.tags
}

resource "aws_secretsmanager_secret_version" "db_master" {
  secret_id     = aws_secretsmanager_secret.db_master.id
  secret_string = jsonencode({ username = "brsr_master", password = random_password.db_master.result })

  lifecycle { ignore_changes = [secret_string] }
}

resource "aws_secretsmanager_secret" "redis_auth" {
  name                    = "${var.name}/redis/auth"
  kms_key_id              = var.kms_key_arn
  recovery_window_in_days = 7
  tags                    = var.tags
}

resource "aws_secretsmanager_secret_version" "redis_auth" {
  secret_id     = aws_secretsmanager_secret.redis_auth.id
  secret_string = jsonencode({ token = random_password.redis_auth.result })

  lifecycle { ignore_changes = [secret_string] }
}

resource "aws_secretsmanager_secret" "anthropic" {
  name                    = "${var.name}/anthropic/api-key"
  kms_key_id              = var.kms_key_arn
  recovery_window_in_days = 7
  tags                    = var.tags
}

resource "aws_secretsmanager_secret" "voyage" {
  name                    = "${var.name}/voyage/api-key"
  kms_key_id              = var.kms_key_arn
  recovery_window_in_days = 7
  tags                    = var.tags
}

resource "aws_secretsmanager_secret" "jwt_signer" {
  name                    = "${var.name}/jwt/signer"
  kms_key_id              = var.kms_key_arn
  recovery_window_in_days = 7
  tags                    = var.tags
}

resource "aws_secretsmanager_secret" "keycloak_admin" {
  name                    = "${var.name}/keycloak/admin"
  kms_key_id              = var.kms_key_arn
  recovery_window_in_days = 7
  tags                    = var.tags
}

# Outputs ---------------------------------------------------------------------

output "db_master_password_arn" { value = aws_secretsmanager_secret.db_master.arn }
output "redis_auth_arn"         { value = aws_secretsmanager_secret.redis_auth.arn }
output "anthropic_arn"          { value = aws_secretsmanager_secret.anthropic.arn }
output "voyage_arn"             { value = aws_secretsmanager_secret.voyage.arn }
output "jwt_signer_arn"         { value = aws_secretsmanager_secret.jwt_signer.arn }
output "keycloak_admin_arn"     { value = aws_secretsmanager_secret.keycloak_admin.arn }
